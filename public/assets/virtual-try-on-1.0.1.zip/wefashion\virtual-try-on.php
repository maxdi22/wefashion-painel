<?php
/**
 * Plugin Name: Virtual Try-On
 * Plugin URI:  https://clbe.tech/virtual-try-on
 * Description: Provador Virtual com IA oficial - Ative em sua loja em minutos.
 * Version:     1.0.1
 * Author:      CLB Enterprises
 * Author URI:  https://clbe.tech
 * Text Domain: virtual-try-on
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define Constants
define( 'VTO_VERSION', '1.0.1' );
define( 'VTO_PATH', plugin_dir_path( __FILE__ ) );
define( 'VTO_URL', plugin_dir_url( __FILE__ ) );

/**
 * Create Leads Table on Activation
 */
function vto_create_leads_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'vto_leads';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        name varchar(100) DEFAULT '',
        email varchar(100) DEFAULT '',
        whatsapp varchar(20) DEFAULT '',
        product_id bigint(20) NOT NULL,
        product_name varchar(255) DEFAULT '',
        image_url text NOT NULL,
        score int DEFAULT 0,
        intent varchar(50) DEFAULT 'baixa',
        looks_count int DEFAULT 1,
        shares_count int DEFAULT 0,
        clicks_count int DEFAULT 0,
        last_action varchar(100) DEFAULT 'Gerou look',
        source varchar(50) DEFAULT 'Direto',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}
register_activation_hook( __FILE__, 'vto_create_leads_table' );

/**
 * Check if WooCommerce is active
 */
function vto_check_woocommerce_active() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', 'vto_woocommerce_not_active_notice' );
        return false;
    }
    return true;
}

function vto_woocommerce_not_active_notice() {
    ?>
    <div class="notice notice-error is-dismissible">
        <p><?php _e( 'O plugin Virtual Try-On requer o WooCommerce ativado para funcionar.', 'virtual-try-on' ); ?></p>
    </div>
    <?php
}

/**
 * Initialize Plugin
 */
function vto_init() {
    if ( ! vto_check_woocommerce_active() ) {
        return;
    }

    // Ensure database table exists
    vto_create_leads_table();

    // Includes
    require_once VTO_PATH . 'admin/settings.php';
    require_once VTO_PATH . 'includes/class-vto-product.php';
    require_once VTO_PATH . 'includes/class-vto-logger.php';
    require_once VTO_PATH . 'includes/class-vto-crm.php';
}
add_action( 'plugins_loaded', 'vto_init' );

/**
 * Handle AJAX for clearing logs
 */
function vto_ajax_clear_logs() {
    check_ajax_referer( 'vto_nonce', 'nonce' );
    VTO_Logger::clear_logs();
    wp_send_json_success( array( 'message' => 'Logs limpos com sucesso.' ) );
}
add_action( 'wp_ajax_vto_clear_logs', 'vto_ajax_clear_logs' );

/**
 * Handle AJAX for logging from JS
 */
function vto_ajax_log_event() {
    check_ajax_referer( 'vto_nonce', 'nonce' );
    $message = isset( $_POST['log_message'] ) ? sanitize_text_field( $_POST['log_message'] ) : '';
    $type = isset( $_POST['log_type'] ) ? sanitize_text_field( $_POST['log_type'] ) : 'info';
    
    if ( $message ) {
        VTO_Logger::log( $message, $type );
    }
    wp_send_json_success();
}
add_action( 'wp_ajax_vto_log_event', 'vto_ajax_log_event' );

/**
 * Handle AJAX for saving Lead
 */
function vto_ajax_save_lead() {
    check_ajax_referer( 'vto_nonce', 'nonce' );
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'vto_leads';
    
    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $whatsapp = isset($_POST['whatsapp']) ? sanitize_text_field($_POST['whatsapp']) : '';
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $product_name = isset($_POST['product_name']) ? sanitize_text_field($_POST['product_name']) : '';
    $image_url = isset($_POST['image_url']) ? esc_url_raw($_POST['image_url']) : '';
    
    // CRM Fields
    $looks_count = isset($_POST['looks_count']) ? intval($_POST['looks_count']) : 1;
    $shares_count = isset($_POST['shares_count']) ? intval($_POST['shares_count']) : 0;
    $clicks_count = isset($_POST['clicks_count']) ? intval($_POST['clicks_count']) : 0;
    $source = isset($_POST['source']) ? sanitize_text_field($_POST['source']) : 'Direto';
    
    // Intelligent Scoring
    $score = VTO_CRM::calculate_score($looks_count, $shares_count, $clicks_count);
    $intent = VTO_CRM::calculate_intent($score, $clicks_count);

    if ( empty($email) && empty($whatsapp) ) {
        wp_send_json_error( array('message' => 'Nenhum contato fornecido.') );
    }

    $inserted = $wpdb->insert(
        $table_name,
        array(
            'name' => $name,
            'email' => $email,
            'whatsapp' => $whatsapp,
            'product_id' => $product_id,
            'product_name' => $product_name,
            'image_url' => $image_url,
            'score' => $score,
            'intent' => $intent,
            'looks_count' => $looks_count,
            'shares_count' => $shares_count,
            'clicks_count' => $clicks_count,
            'source' => $source,
            'last_action' => 'Salvou look',
            'time' => current_time('mysql')
        )
    );

    if ( $inserted ) {
        $api_url    = get_option( 'vto_api_url', '' );
        $tenant_id  = get_option( 'vto_store_id', '' );
        $public_key = get_option( 'vto_public_key', '' );

        if ( ! empty( $api_url ) && ! empty( $tenant_id ) ) {
            wp_remote_post( $api_url . '/api/sync/lead', array(
                'headers'     => array(
                    'Content-Type' => 'application/json',
                    'X-Public-Key' => $public_key
                ),
                'body'        => json_encode( array(
                    'tenant_id'        => $tenant_id,
                    'job_id'           => isset($_POST['job_id']) ? sanitize_text_field($_POST['job_id']) : 'manual_' . time(),
                    'product_id'       => (string)$product_id,
                    'name'             => $name,
                    'email'            => $email,
                    'whatsapp'         => $whatsapp,
                    'result_image_url' => $image_url,
                    'source'           => 'wordpress'
                ) ),
                'timeout'     => 15,
                'blocking'    => false, // Async so it doesn't slow down the user
            ) );
        }
        
        wp_send_json_success( array('message' => 'Lead salvo com sucesso no CRM local e sincronizado.') );
    } else {
        wp_send_json_error( array('message' => 'Erro ao salvar lead no banco de dados.') );
    }
}
add_action( 'wp_ajax_vto_save_lead', 'vto_ajax_save_lead' );

/**
 * Proxy for direct image download (Bypass CORS)
 */
function vto_ajax_proxy_download() {
    $image_url = isset($_GET['image_url']) ? esc_url_raw($_GET['image_url']) : '';
    if (empty($image_url)) {
        wp_die('URL da imagem inválida.');
    }

    // Baixa a imagem via servidor
    $response = wp_remote_get($image_url, array('timeout' => 30));
    
    if (is_wp_error($response)) {
        wp_die('Erro ao baixar imagem: ' . $response->get_error_message());
    }

    $code = wp_remote_retrieve_response_code($response);
    if ($code !== 200) {
        wp_die('Erro do servidor de imagens: Código ' . $code);
    }

    $image_data = wp_remote_retrieve_body($response);
    $content_type = wp_remote_retrieve_header($response, 'content-type');
    
    if (empty($content_type)) {
        $content_type = 'image/jpeg';
    }

    // Força o download
    header('Content-Description: File Transfer');
    header('Content-Type: ' . $content_type);
    header('Content-Disposition: attachment; filename="meu-look-wefashion-' . time() . '.jpg"');
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . strlen($image_data));
    
    echo $image_data;
    exit;
}
add_action( 'wp_ajax_vto_proxy_download', 'vto_ajax_proxy_download' );
add_action( 'wp_ajax_nopriv_vto_proxy_download', 'vto_ajax_proxy_download' );

/**
 * Enqueue scripts and styles
 */
function vto_enqueue_scripts() {
    if ( ! is_product() ) {
        return;
    }
    
    $product_id = get_the_ID();
    $vto_product = wc_get_product( $product_id );
    
    if ( ! $vto_product ) {
        return;
    }

    // Check activation mode
    $mode = get_option('vto_activation_mode', 'specific');
    if ($mode === 'specific') {
        $enabled = get_post_meta($product_id, '_vto_enabled', true);
        if ($enabled !== 'yes') {
            return;
        }
    }

    wp_enqueue_style( 'vto-modal-css', VTO_URL . 'public/css/vto-modal.css', array(), VTO_VERSION );
    wp_enqueue_script( 'vto-main-js', VTO_URL . 'public/js/vto-main.js', array( 'jquery' ), VTO_VERSION, true );

    // Detect product category for IA (top, bottom, fullbody)
    $product_type = 'top'; // default
    $gender       = 'unisex';
    
    $terms = get_the_terms($product_id, 'product_cat');
    if ($terms && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $cat_name = mb_strtolower($term->name);
            
            // Type detection
            if (strpos($cat_name, 'calça') !== false || strpos($cat_name, 'short') !== false || strpos($cat_name, 'saia') !== false) {
                $product_type = 'bottom';
            }
            if (strpos($cat_name, 'vestido') !== false || strpos($cat_name, 'macacão') !== false) {
                $product_type = 'fullbody';
                $gender = 'female'; // Vestido/Macacão costuma ser feminino
            }

            // Gender detection
            if (strpos($cat_name, 'fem') !== false || strpos($cat_name, 'mulher') !== false || strpos($cat_name, 'menina') !== false) {
                $gender = 'female';
            }
            if (strpos($cat_name, 'masc') !== false || strpos($cat_name, 'homem') !== false || strpos($cat_name, 'menino') !== false) {
                $gender = 'male';
            }
        }
    }

    $foot_rules = "FOOT RENDERING RULES:
- Always generate aesthetically pleasing, well-shaped, and elegant feet.
- Maintain correct anatomical proportions and structure. 
- Avoid distortions, extra toes, or unnatural curvature.
- Skin smooth, clean, and evenly lit.
- Nails natural and well-groomed.
- FOOTWEAR INTERACTION: Ensure realistic interaction avoid clipping or floating.
- VISUAL PRIORITY: Feet are an important aesthetic element equivalent to face/hands.";

    if ($gender === 'female') {
        $foot_rules .= "\nFEMALE SPECIFIC: Feet must appear refined, feminine, and visually attractive. Smooth texture, delicacy and aligned toes.";
    } else if ($gender === 'male') {
        $foot_rules .= "\nMALE SPECIFIC: Feet must appear natural, clean, and proportionally correct. Maintain realistic masculine structure.";
    }

    // Pass data to JS
    wp_localize_script( 'vto-main-js', 'vto_data', array(
        'ajax_url'    => admin_url( 'admin-ajax.php' ),
        'api_url'     => get_option( 'vto_api_url', 'http://localhost:3000' ),
        'tenant_id'   => get_option( 'vto_store_id', '' ),
        'public_key'  => get_option( 'vto_public_key', '' ),
        'nonce'       => wp_create_nonce( 'vto_nonce' ),
        'product'     => array(
            'id'    => $vto_product->get_id(),
            'name'  => $vto_product->get_name(),
            'type'  => $product_type,
            'price' => $vto_product->get_price(),
            'price_html' => wp_strip_all_tags( wc_price( $vto_product->get_price() ) ),
            'image' => get_the_post_thumbnail_url( $vto_product->get_id(), 'full' ),
            'optimized_image' => get_post_meta($product_id, '_vto_optimized_image_url', true),
            'meta'  => array(
                'category' => get_post_meta($product_id, '_vto_category', true),
                'scope'    => get_post_meta($product_id, '_vto_scope', true),
                'length'   => get_post_meta($product_id, '_vto_length', true),
                'fit'      => get_post_meta($product_id, '_vto_fit', true),
                'notes'    => get_post_meta($product_id, '_vto_notes', true),
                'gender'   => $gender,
                'foot_rules' => $foot_rules
            ),
            'variations' => $vto_product->is_type('variable') ? $vto_product->get_available_variations() : array(),
            'attributes' => $vto_product->is_type('variable') ? $vto_product->get_variation_attributes() : array(),
        )
    ) );
}
add_action( 'wp_enqueue_scripts', 'vto_enqueue_scripts' );

