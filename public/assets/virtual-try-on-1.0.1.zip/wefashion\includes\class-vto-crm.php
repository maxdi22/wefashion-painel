<?php
/**
 * VTO Intelligent CRM Class
 */

class VTO_CRM {
    
    /**
     * Calculate Score (0-100)
     */
    public static function calculate_score($looks, $shares, $clicks) {
        $score = 0;
        
        $score += ($looks * 10);   // Cada look gerado: 10 pts
        $score += ($shares * 25);  // Cada compartilhamento: 25 pts
        $score += ($clicks * 50);  // Cada clique em comprar: 50 pts
        
        return min(100, $score);
    }
    
    /**
     * Calculate Intent
     */
    public static function calculate_intent($score, $clicks) {
        if ($clicks > 0 || $score >= 60) {
            return 'alta';
        }
        if ($score >= 30) {
            return 'media';
        }
        return 'baixa';
    }

    /**
     * Get KPI Data
     */
    public static function get_kpis() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'vto_leads';
        
        $results = array();
        
        // Leads Hoje
        $results['leads_today'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE DATE(time) = CURDATE()");
        
        // Alta Intenção
        $results['high_intent'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE intent = 'alta'");
        
        // Clicaram em Comprar
        $results['clicks_buy'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE clicks_count > 0");
        
        // Geração total de looks
        $results['total_looks'] = $wpdb->get_var("SELECT SUM(looks_count) FROM $table_name");
        
        // Taxa de intenção alta
        $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        $results['conversion_rate'] = ($total > 0) ? round(($results['high_intent'] / $total) * 100, 1) : 0;
        
        return $results;
    }

    /**
     * Get Badge HTML for Intent
     */
    public static function get_intent_badge($intent) {
        $color = '#aaa';
        $label = 'Baixa';
        
        switch($intent) {
            case 'alta':
                $color = '#10b981'; // Verde
                $label = 'ALTA';
                break;
            case 'media':
                $color = '#f59e0b'; // Laranja
                $label = 'MÉDIA';
                break;
        }
        
        return sprintf(
            '<span style="background: %s; color: white; padding: 4px 10px; border-radius: 4px; font-size: 10px; font-weight: bold;">%s</span>',
            $color,
            $label
        );
    }

    /**
     * Get Badge HTML for Score
     */
    public static function get_score_badge($score) {
        $color = '#6b7280'; // Cinza
        if ($score >= 60) $color = '#10b981'; // Verde
        else if ($score >= 30) $color = '#f59e0b'; // Laranja
        
        return sprintf(
            '<div style="display: inline-flex; align-items: center; gap: 6px;">
                <div style="width: 32px; height: 32px; border-radius: 50%%; border: 3px solid %s; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; color: %s">
                    %d
                </div>
            </div>',
            $color,
            $color,
            $score
        );
    }
}
