<?php
/**
 * Admin Settings for Virtual Try-On
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add Menu to Admin
 */
function vto_add_admin_menu() {
    add_menu_page(
        'Virtual Try-On',
        'Try-On IA',
        'manage_options',
        'virtual-try-on',
        'vto_render_settings_page',
        'dashicons-camera',
        56
    );

    add_submenu_page(
        'virtual-try-on',
        'Configurações',
        'Configurações',
        'manage_options',
        'virtual-try-on',
        'vto_render_settings_page'
    );

    add_submenu_page(
        'virtual-try-on',
        'Leads Capturados',
        'Leads (CRM)',
        'manage_options',
        'vto-leads',
        'vto_render_leads_page'
    );
}
add_action( 'admin_menu', 'vto_add_admin_menu' );

/**
 * Enqueue Admin Scripts
 */
function vto_admin_settings_enqueue_scripts($hook) {
    if ('toplevel_page_virtual-try-on' === $hook) {
        wp_enqueue_script('vto-settings-js', plugin_dir_url(__FILE__) . 'js/settings.js', array('jquery'), '1.0.0', true);
    }
    
    if ('try-on-ia_page_vto-leads' === $hook) {
        wp_enqueue_style('vto-crm-css', plugin_dir_url(__FILE__) . 'css/vto-crm.css', array(), '1.0.0');
        wp_enqueue_script('vto-crm-js', plugin_dir_url(__FILE__) . 'js/vto-crm.js', array('jquery'), '1.0.0', true);
    }
}
add_action('admin_enqueue_scripts', 'vto_admin_settings_enqueue_scripts');

/**
 * Register Settings
 */
function vto_register_settings() {
    register_setting( 'vto_settings_group', 'vto_api_url' );
    register_setting( 'vto_settings_group', 'vto_store_id' );
    register_setting( 'vto_settings_group', 'vto_public_key' );
    register_setting( 'vto_settings_group', 'vto_install_token' );
    register_setting( 'vto_settings_group', 'vto_activation_mode' );
}
add_action( 'admin_init', 'vto_register_settings' );

/**
 * Render Settings Page
 */
function vto_render_settings_page() {
    $status = get_option('vto_connection_status', 'disconnected');
    $status_color = ($status === 'connected') ? '#10b981' : '#f59e0b';
    ?>
    <div class="wrap">
        <h1>
            Configurações do Virtual Try-On 
            <span style="font-size: 12px; background: <?php echo $status_color; ?>; color: white; padding: 4px 12px; border-radius: 100px; vertical-align: middle; margin-left: 10px;">
                <?php echo strtoupper($status); ?>
            </span>
        </h1>
        
        <form method="post" action="options.php" id="vto-settings-form">
            <?php settings_fields( 'vto_settings_group' ); ?>
            <?php do_settings_sections( 'vto_settings_group' ); ?>
            
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">API Base URL</th>
                    <td>
                        <input type="text" name="vto_api_url" value="<?php echo esc_attr( get_option( 'vto_api_url', 'http://localhost:3000' ) ); ?>" class="regular-text" placeholder="http://localhost:3000" />
                        <p class="description">URL base do seu painel SaaS WeFashion.</p>
                    </td>
                </tr>
                
                <tr valign="top">
                    <th scope="row">Tenant ID</th>
                    <td>
                        <input type="text" name="vto_store_id" value="<?php echo esc_attr( get_option( 'vto_store_id' ) ); ?>" class="regular-text" placeholder="Ex: tenant_..." />
                    </td>
                </tr>
                
                <tr valign="top">
                    <th scope="row">Public Key</th>
                    <td>
                        <input type="text" name="vto_public_key" value="<?php echo esc_attr( get_option( 'vto_public_key' ) ); ?>" class="regular-text" placeholder="Ex: pk_test_..." />
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Install Token</th>
                    <td>
                        <input type="password" name="vto_install_token" value="<?php echo esc_attr( get_option( 'vto_install_token' ) ); ?>" class="regular-text" placeholder="tok_..." />
                    </td>
                </tr>

                <tr valign="top">
                    <td colspan="2"><hr /><h2>Disponibilidade do provador</h2></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Modo de ativação</th>
                    <td>
                        <?php $mode = get_option( 'vto_activation_mode', 'specific' ); ?>
                        <select name="vto_activation_mode" class="regular-text">
                            <option value="all" <?php selected( $mode, 'all' ); ?>>Todos os produtos</option>
                            <option value="specific" <?php selected( $mode, 'specific' ); ?>>Apenas produtos específicos</option>
                        </select>
                        <p class="description">Escolha se o botão do provador aparecerá em toda a loja ou somente nos produtos marcados manualmente.</p>
                    </td>
                </tr>
            </table>

            <div id="vto-test-result" style="margin-top: 20px; padding: 15px; border-radius: 8px; display: none;"></div>
            
            <div style="margin-top: 20px;">
                <?php submit_button( 'Salvar Credenciais', 'primary', 'submit', false ); ?>
                <button type="button" id="vto-register-plugin" class="button button-secondary" style="margin-left: 10px; background: #6366f1; color: white; border-color: #4f46e5;">Ativar Integração</button>
                <button type="button" id="vto-test-connection" class="button button-link" style="margin-left: 10px;">Verificar Saúde da API</button>
            </div>
        </form>

        <hr style="margin-top: 40px;" />
        
        <h2>Logs de Integração Recentes</h2>
        <div id="vto-logs-container" style="background: #fff; border: 1px solid #ccd0d4; padding: 15px; border-radius: 8px; max-height: 300px; overflow-y: auto;">
            <?php
            $logs = VTO_Logger::get_logs();
            if ( empty( $logs ) ) {
                echo '<p>Nenhum log registrado ainda.</p>';
            } else {
                echo '<ul style="margin: 0; padding: 0; list-style: none;">';
                foreach ( $logs as $log ) {
                    $color = $log['type'] === 'error' ? '#d63638' : '#2271b1';
                    echo '<li style="margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px solid #eee;">';
                    echo '<strong>[' . esc_html( $log['timestamp'] ) . ']</strong> ';
                    echo '<span style="color: ' . $color . ';">' . esc_html( $log['message'] ) . '</span>';
                    echo '</li>';
                }
                echo '</ul>';
            }
            ?>
        </div>
        <p><button type="button" id="vto-clear-logs" class="button button-link" style="color: #d63638;">Limpar Logs</button></p>
    </div>
    <?php
}

/**
 * Render Leads Page (Mini CRM)
 */
function vto_render_leads_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'vto_leads';
    
    // 1. KPIs
    $kpis = VTO_CRM::get_kpis();
    
    // 2. Filters Logic
    $intent_filter = isset($_GET['intent']) ? sanitize_text_field($_GET['intent']) : '';
    $action_filter = isset($_GET['action_type']) ? sanitize_text_field($_GET['action_type']) : '';
    
    $where = "WHERE 1=1";
    if ($intent_filter) {
        $where .= $wpdb->prepare(" AND intent = %s", $intent_filter);
    }
    if ($action_filter === 'clicked_buy') {
        $where .= " AND clicks_count > 0";
    } elseif ($action_filter === 'shared') {
        $where .= " AND shares_count > 0";
    } elseif ($action_filter === 'multiple_looks') {
        $where .= " AND looks_count > 1";
    }
    
    $leads = $wpdb->get_results( "SELECT * FROM $table_name $where ORDER BY time DESC", ARRAY_A );
    ?>
    <div class="vto-crm-wrap">
        <h1 style="margin-bottom: 25px;">Inteligência de Leads - WeFashion CRM</h1>

        <!-- KPI HEADER -->
        <div class="vto-kpi-grid">
            <div class="vto-kpi-card">
                <div class="vto-kpi-label">Captados Hoje</div>
                <div class="vto-kpi-value"><?php echo number_format($kpis['leads_today']); ?></div>
            </div>
            <div class="vto-kpi-card" style="border-top: 4px solid #10b981;">
                <div class="vto-kpi-label">Alta Intenção</div>
                <div class="vto-kpi-value" style="color: #10b981;"><?php echo number_format($kpis['high_intent']); ?></div>
            </div>
            <div class="vto-kpi-card" style="border-top: 4px solid #3b82f6;">
                <div class="vto-kpi-label">Cliques em Comprar</div>
                <div class="vto-kpi-value" style="color: #3b82f6;"><?php echo number_format($kpis['clicks_buy']); ?></div>
            </div>
            <div class="vto-kpi-card">
                <div class="vto-kpi-label">Looks Gerados</div>
                <div class="vto-kpi-value"><?php echo number_format($kpis['total_looks']); ?></div>
            </div>
            <div class="vto-kpi-card">
                <div class="vto-kpi-label">Conversão (Intenção)</div>
                <div class="vto-kpi-value"><?php echo $kpis['conversion_rate']; ?>%</div>
            </div>
        </div>

        <!-- FILTERS BAR -->
        <div class="vto-filters-bar">
            <span style="font-weight: 600; font-size: 13px; color: #64748b;">Filtrar por:</span>
            
            <select class="vto-filter-select" onchange="location.href='?page=vto-leads&intent=' + this.value">
                <option value="">Todas as Intenções</option>
                <option value="alta" <?php selected($intent_filter, 'alta'); ?>>Alta Intenção</option>
                <option value="media" <?php selected($intent_filter, 'media'); ?>>Média Intenção</option>
                <option value="baixa" <?php selected($intent_filter, 'baixa'); ?>>Baixa Intenção</option>
            </select>

            <select class="vto-filter-select" onchange="location.href='?page=vto-leads&action_type=' + this.value">
                <option value="">Todas as Ações</option>
                <option value="clicked_buy" <?php selected($action_filter, 'clicked_buy'); ?>>Clicaram em Comprar</option>
                <option value="shared" <?php selected($action_filter, 'shared'); ?>>Compartilharam</option>
                <option value="multiple_looks" <?php selected($action_filter, 'multiple_looks'); ?>>Mais de 1 look</option>
            </select>

            <a href="?page=vto-leads" class="button button-link">Limpar Filtros</a>
        </div>

        <!-- CRM TABLE -->
        <div class="vto-crm-table-container">
            <input type="hidden" id="vto_crm_nonce" value="<?php echo wp_create_nonce('vto_crm_nonce'); ?>">
            <table class="vto-crm-table">
                <thead>
                    <tr>
                        <th style="width: 220px;">Cliente</th>
                        <th>Score</th>
                        <th>Intenção</th>
                        <th>Produto de Interesse</th>
                        <th>Interações</th>
                        <th>Última Ação</th>
                        <th>Data</th>
                        <th style="text-align: right;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $leads ) ) : ?>
                        <tr>
                            <td colspan="8" style="padding: 40px; text-align: center; color: #94a3b8;">
                                <div style="font-size: 16px;">Nenhum lead encontrado com estes filtros.</div>
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ( $leads as $lead ) : ?>
                            <tr>
                                <td>
                                    <div class="vto-lead-client vto-lead-details-trigger" data-id="<?php echo $lead['id']; ?>" style="cursor: pointer;">
                                        <span class="vto-lead-name"><?php echo esc_html( $lead['name'] ?: 'Visitante' ); ?></span>
                                        <span class="vto-lead-id">ID #<?php echo $lead['id']; ?> • <?php echo esc_html($lead['source']); ?></span>
                                        <span class="vto-lead-id" style="margin-top:2px"><?php echo esc_html($lead['email']); ?></span>
                                    </div>
                                </td>
                                <td><?php echo VTO_CRM::get_score_badge($lead['score']); ?></td>
                                <td><?php echo VTO_CRM::get_intent_badge($lead['intent']); ?></td>
                                <td>
                                    <div style="font-weight: 500; font-size: 13px; color: #334155;">
                                        <?php echo esc_html($lead['product_name']); ?>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-size: 12px; color: #64748b;">
                                        <div><span class="vto-interaction-dot" style="background:#3b82f6"></span> <?php echo $lead['looks_count']; ?> Looks</div>
                                        <div><span class="vto-interaction-dot" style="background:#10b981"></span> <?php echo $lead['shares_count']; ?> Envios</div>
                                        <div><span class="vto-interaction-dot" style="background:#f59e0b"></span> <?php echo $lead['clicks_count']; ?> Cliques</div>
                                    </div>
                                </td>
                                <td>
                                    <span style="font-size: 13px; color: #475569;">
                                        <?php echo esc_html($lead['last_action']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="font-size: 12px; color: #64748b;">
                                        <?php echo esc_html( date('d/m/Y H:i', strtotime($lead['time'])) ); ?>
                                    </span>
                                </td>
                                <td style="text-align: right;">
                                    <a href="#" class="vto-action-btn vto-lead-details-trigger" data-id="<?php echo $lead['id']; ?>" title="Detalhes">
                                        <span class="dashicons dashicons-id-alt"></span>
                                    </a>
                                    <?php if ( $lead['whatsapp'] ) : ?>
                                        <a href="https://wa.me/<?php echo esc_attr(preg_replace('/\D/', '', $lead['whatsapp'])); ?>?text=Ola%20<?php echo urlencode($lead['name']); ?>!%20Vi%20que%20voce%20testou%20o%20produto%20<?php echo urlencode($lead['product_name']); ?>%20no%20nosso%20provador..." target="_blank" class="vto-action-btn whatsapp" title="WhatsApp">
                                            <span class="dashicons dashicons-whatsapp"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo esc_url($lead['image_url']); ?>" target="_blank" class="vto-action-btn" title="Ver Look">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </a>
                                    <a href="<?php echo get_permalink($lead['product_id']); ?>" target="_blank" class="vto-action-btn" title="Ver Produto">
                                        <span class="dashicons dashicons-products"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- INSIGHTS SECTION -->
        <div class="vto-insights-section">
            <div class="vto-insights-title">
                <span class="dashicons dashicons-lightbulb"></span> Insights de Leads WeFashion
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="vto-insight-item">
                    <strong>Ponto Cego:</strong> Leads com Intenção Alta que compartilharam o look tendem a fechar compra 3x mais rápido se contatados em menos de 10 minutos.
                </div>
                <div class="vto-insight-item">
                    <strong>Otimização:</strong> O produto "<?php echo esc_html($leads[0]['product_name'] ?? 'mais testado'); ?>" é o maior gerador de intenção de compra hoje. Considere criar uma promoção para ele.
                </div>
            </div>
        </div>

        <!-- LEAD DETAILS MODAL (Slide-over) -->
        <div id="vto-crm-modal" style="display:none;">
            <div class="vto-crm-modal-overlay" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.4); z-index:100000;"></div>
            <div id="vto-crm-modal-panel" style="position:fixed; top:0; right:0; width:450px; height:100%; background:#fff; z-index:100001; box-shadow:-5px 0 30px rgba(0,0,0,0.1); display:flex; flex-direction:column;">
                <div style="padding:20px; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
                    <h2 style="margin:0; font-size:18px;">Perfil do Lead</h2>
                    <button class="vto-crm-modal-close" style="background:none; border:none; cursor:pointer; font-size:20px; color:#94a3b8;">&times;</button>
                </div>
                <div id="vto-crm-modal-content" style="flex:1; overflow-y:auto; padding:25px;">
                    <!-- Content via AJAX -->
                </div>
            </div>
        </div>
    </div>
    <?php
}
