jQuery(document).ready(function($) {
    const $form = $('#vto-settings-form');
    const $testBtn = $('#vto-test-connection');
    const $registerBtn = $('#vto-register-plugin');
    const $result = $('#vto-test-result');

    function showStatus(message, type = 'info') {
        const colors = {
            success: '#d4edda',
            error: '#f8d7da',
            info: '#cce5ff'
        };
        const textColors = {
            success: '#155724',
            error: '#721c24',
            info: '#004085'
        };
        $result.css({
            display: 'block',
            backgroundColor: colors[type],
            color: textColors[type],
            border: `1px solid ${textColors[type]}`
        }).html(message);
    }

    $testBtn.on('click', function() {
        const apiUrl = $('input[name="vto_api_url"]').val();
        
        showStatus('Verificando API...');
        
        fetch(`${apiUrl}/v1/health/check`)
            .then(res => res.json())
            .then(data => {
                if (data.status === 'OK' || (data.success && data.api_status === 'online')) {
                    showStatus('✅ API WeFashion Online. Pronto para ativação.', 'success');
                } else {
                    showStatus('⚠️ API respondeu com status degradado: ' + (data.api_status || 'desconhecido'), 'error');
                }
            })
            .catch(err => {
                showStatus('❌ Não foi possível contatar a API. Verifique a URL e se o servidor está rodando.', 'error');
                console.error(err);
            });
    });

    $registerBtn.on('click', function() {
        const apiUrl = $('input[name="vto_api_url"]').val();
        const tenantId = $('input[name="vto_store_id"]').val();
        const publicKey = $('input[name="vto_public_key"]').val();
        const installToken = $('input[name="vto_install_token"]').val();

        if (!tenantId || !installToken) {
            showStatus('Preencha o Tenant ID e o Install Token para ativar.', 'error');
            return;
        }

        showStatus('Enviando solicitação de registro...');

        fetch(`${apiUrl}/v1/plugin/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                tenantId: tenantId,
                installToken: installToken,
                siteUrl: window.location.origin,
                pluginVersion: '1.0.0'
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                showStatus(`✅ <b>Integração Ativada!</b><br>Secret Key recebida: <code>${data.secretKey.substr(0, 10)}...</code><br>Salve as configurações para concluir.`, 'success');
                // Opcional: Salvar automaticamente via AJAX se quiser
            } else {
                showStatus('❌ Erro no registro: ' + data.message, 'error');
            }
        })
        .catch(err => {
            showStatus('❌ Erro ao comunicar com o servidor de registro.', 'error');
            console.error(err);
        });
    });
});
