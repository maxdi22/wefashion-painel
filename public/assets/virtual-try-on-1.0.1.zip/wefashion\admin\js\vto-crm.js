jQuery(document).ready(function($) {
    'use strict';

    const CRM = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            // Click on Lead Name or Detail Icon
            $(document).on('click', '.vto-lead-details-trigger', (e) => {
                e.preventDefault();
                const leadId = $(e.currentTarget).data('id');
                this.openModal(leadId);
            });

            // Close Modal
            $(document).on('click', '.vto-crm-modal-close, .vto-crm-modal-overlay', () => {
                this.closeModal();
            });
        },

        openModal: function(leadId) {
            const $modal = $('#vto-crm-modal');
            const $content = $('#vto-crm-modal-content');
            
            $modal.show();
            $content.html('<div style="padding: 40px; text-align: center;"><span class="dashicons dashicons-update spin"></span> Carregando inteligência do lead...</div>');

            $.post(ajaxurl, {
                action: 'vto_get_lead_details',
                lead_id: leadId,
                nonce: $('#vto_crm_nonce').val()
            }, (res) => {
                if (res.success) {
                    $content.html(res.data.html);
                } else {
                    $content.html('<div style="padding: 20px; color: #d63638;">Erro ao carregar dados: ' + res.data.message + '</div>');
                }
            });
        },

        closeModal: function() {
            $('#vto-crm-modal').hide();
        }
    };

    CRM.init();
});
