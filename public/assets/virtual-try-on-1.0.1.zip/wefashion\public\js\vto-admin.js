/**
 * Virtual Try-On Admin JS
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        const $testBtn = $('#vto-test-connection');
        const $resultArea = $('#vto-test-result');

        $testBtn.on('click', function() {
            const apiUrl = $('input[name="vto_api_url"]').val();
            const storeId = $('input[name="vto_store_id"]').val();
            const publicKey = $('input[name="vto_public_key"]').val();

            if (!apiUrl || !storeId || !publicKey) {
                showResult('❌ Preencha todos os campos antes de testar.', 'error');
                return;
            }

            $testBtn.prop('disabled', true).text('Testando...');
            $resultArea.hide();

            // Chamada direta para o Health Check do Backend
            fetch(`${apiUrl}/health/check`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Store-ID': storeId,
                    'X-Public-Key': publicKey,
                    'X-Timestamp': Math.floor(Date.now() / 1000).toString(),
                    'X-Signature': 'mock_signature'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'healthy') {
                    showResult('✅ Sucesso! Conectado ao Backend VTO Core.', 'success');
                    logToWP(`Conexão bem-sucedida com a API: ${apiUrl}`, 'info');
                } else {
                    const errorMsg = data.error || 'Erro desconhecido no backend.';
                    showResult(`❌ Falha na conexão: ${errorMsg}`, 'error');
                    logToWP(`Falha no Health Check: ${errorMsg}`, 'error');
                }
            })
            .catch(err => {
                const msg = `Não foi possível alcançar a API em ${apiUrl}. Verifique a URL e o CORS.`;
                showResult(`❌ Erro de rede: ${msg}`, 'error');
                logToWP(msg, 'error');
                console.error('VTO Health Check Error:', err);
            })
            .finally(() => {
                $testBtn.prop('disabled', false).text('Testar Conexão');
            });
        });

        // Limpar Logs
        $('#vto-clear-logs').on('click', function() {
            if (!confirm('Tem certeza que deseja limpar todos os logs?')) return;
            
            $.post(ajaxurl, {
                action: 'vto_clear_logs',
                nonce: vto_data.nonce
            }, function(res) {
                if (res.success) {
                    $('#vto-logs-container').html('<p>Nenhum log registrado ainda.</p>');
                }
            });
        });

        function logToWP(message, type) {
            $.post(ajaxurl, {
                action: 'vto_log_event',
                nonce: vto_data.nonce,
                log_message: message,
                log_type: type
            });
        }

        function showResult(msg, type) {
            const bgColor = type === 'success' ? '#d4edda' : '#f8d7da';
            const textColor = type === 'success' ? '#155724' : '#721c24';
            const borderColor = type === 'success' ? '#c3e6cb' : '#f5c6cb';

            $resultArea
                .html(msg)
                .css({
                    'display': 'block',
                    'background-color': bgColor,
                    'color': textColor,
                    'border': `1px solid ${borderColor}`
                });
        }
    });

})(jQuery);
