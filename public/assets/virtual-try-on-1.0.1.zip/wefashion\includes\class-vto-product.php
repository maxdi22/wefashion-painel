<?php
/**
 * Product Page Integration for Virtual Try-On - Fashion App UX
 * Encoding: UTF-8
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enqueue admin scripts for product page
 */
function vto_admin_product_scripts( $hook ) {
    global $post_type;
    if ( ( $hook == 'post-new.php' || $hook == 'post.php' ) && $post_type == 'product' ) {
        wp_enqueue_media();
    }
}
add_action( 'admin_enqueue_scripts', 'vto_admin_product_scripts' );

/**
 * Trigger button on product page
 */
function vto_add_try_on_button() {
    global $product;
    if ( ! $product ) return;

    // Check activation mode - MUST BE BEFORE ANY OUTPUT
    $mode = get_option('vto_activation_mode', 'specific');
    if ($mode === 'specific') {
        $enabled = get_post_meta($product->get_id(), '_vto_enabled', true);
        if ($enabled !== 'yes') {
            return;
        }
    }

    ?>
    <div class="vto-trigger-wrap">
        <button type="button" id="vto-open-modal" class="vto-trigger-btn">
            <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/></svg>
            Experimentar na minha foto
        </button>
    </div>
    <style>
    .vto-trigger-wrap { margin: 14px 0 4px; }
    .vto-trigger-btn {
        background: #fff;
        border: 1.5px solid #e0e0e0;
        color: #111;
        padding: 12px 18px;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: border-color .18s, background .18s;
        font-family: 'Inter', -apple-system, sans-serif;
    }
    .vto-trigger-btn:hover { border-color: #aaa; background: #fafafa; }
    </style>
    <?php
    add_action( 'wp_footer', 'vto_render_modal_html' );
}
add_action( 'woocommerce_after_add_to_cart_form', 'vto_add_try_on_button' );

/**
 * Product Admin Metabox - Virtual Try-On
 */
function vto_add_product_admin_tab( $tabs ) {
    $tabs['vto_settings'] = array(
        'label'    => __( 'Virtual Try-On', 'wefashion' ),
        'target'   => 'vto_product_data',
        'class'    => array( 'show_if_simple', 'show_if_variable' ),
        'priority' => 70,
    );
    return $tabs;
}
add_filter( 'woocommerce_product_data_tabs', 'vto_add_product_admin_tab' );

function vto_render_product_admin_tab_content() {
    global $post;
    ?>
    <div id="vto_product_data" class="panel woocommerce_options_panel hidden">
        <div class="options_group">
            <h4 style="margin-left: 12px; border-bottom: 1px solid #eee; padding-bottom: 8px;">Configurações do Provador Virtual</h4>
            <p style="margin-left: 12px; color: #666; font-size: 13px;">Estas informações ajudam a nossa IA a vestir a peça corretamente no avatar do cliente.</p>
            
            <?php
            $mode = get_option('vto_activation_mode', 'specific');
            $display_style = ($mode === 'all') ? 'style="display:none;"' : '';
            ?>
            <div id="vto-activation-field" <?php echo $display_style; ?>>
                <?php
                woocommerce_wp_checkbox( array(
                    'id'            => '_vto_enabled',
                    'label'         => __( 'Ativar Virtual Try-On', 'wefashion' ),
                    'description'   => __( 'Ativa o botão de provador para este produto.', 'wefashion' ),
                ) );
                ?>
            </div>
            
            <?php
            woocommerce_wp_select( array(
                'id'      => '_vto_category',
                'label'   => __( 'Tipo da peça', 'wefashion' ),
                'options' => array(
                    ''          => 'Selecione...',
                    'dress'     => 'Vestido',
                    'top'       => 'Blusa / Top',
                    'tshirt'    => 'Camiseta',
                    'jacket'    => 'Blazer / Jaqueta',
                    'pants'     => 'Calça',
                    'shorts'    => 'Shorts',
                    'skirt'     => 'Saia',
                    'jumpsuit'  => 'Macacão',
                    'set'       => 'Conjunto'
                ),
            ) );

            woocommerce_wp_select( array(
                'id'      => '_vto_scope',
                'label'   => __( 'Escopo da peça', 'wefashion' ),
                'options' => array(
                    'upper_body' => 'Parte de cima',
                    'lower_body' => 'Parte de baixo',
                    'full_body'  => 'Corpo inteiro'
                ),
            ) );
            ?>
        </div>

        <div class="options_group">
            <p style="padding: 10px 12px; background: #f9f9f9; font-weight: 600; cursor: pointer;" onclick="jQuery('#vto-adv-fields').toggle()">
                Opções Avançadas (IA) <span style="float:right;">▼</span>
            </p>
            <div id="vto-adv-fields" style="display:none; padding: 10px 0;">
                <?php
                woocommerce_wp_select( array(
                    'id'      => '_vto_length',
                    'label'   => __( 'Comprimento', 'wefashion' ),
                    'options' => array(
                        'cropped' => 'Cropped',
                        'regular' => 'Regular',
                        'long'    => 'Longo',
                        'mini'    => 'Mini',
                        'midi'    => 'Midi'
                    ),
                ) );

                woocommerce_wp_select( array(
                    'id'      => '_vto_fit',
                    'label'   => __( 'Caimento', 'wefashion' ),
                    'options' => array(
                        'slim'      => 'Justo',
                        'regular'   => 'Reto',
                        'loose'     => 'Solto',
                        'oversized' => 'Oversized'
                    ),
                ) );

                woocommerce_wp_text_input( array(
                    'id'          => '_vto_notes',
                    'label'       => __( 'Obs para IA', 'wefashion' ),
                    'placeholder' => 'Ex: gola alta, manga bufante...',
                    'desc_tip'    => true,
                    'description' => __( 'Detalhes extras que ajudam a fidelidade.', 'wefashion' ),
                ) );
                ?>
            </div>
        </div>

        <div class="options_group">
            <h4 style="margin-left: 12px; border-bottom: 1px solid #eee; padding-bottom: 8px;">Otimização (Opcional)</h4>
            <div style="padding: 10px 12px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;"><?php _e( 'Imagem otimizada para provador', 'wefashion' ); ?></label>
                <p style="color: #666; font-size: 13px; margin-bottom: 12px;">Use uma imagem mais limpa ou focada no produto (ex: manequim fantasma) para melhorar o resultado do provador virtual.</p>
                
                <div id="vto-optimized-image-preview" style="margin-bottom: 15px; <?php echo get_post_meta($post->ID, '_vto_optimized_image_url', true) ? '' : 'display:none;'; ?>">
                    <img src="<?php echo esc_url(get_post_meta($post->ID, '_vto_optimized_image_url', true)); ?>" style="max-width: 150px; height: auto; border-radius: 8px; border: 1px solid #ddd; display: block;" />
                    <button type="button" id="vto-remove-optimized-image" class="button button-link-delete" style="margin-top: 8px; color: #a00; padding: 0;"><?php _e( 'Remover imagem', 'wefashion' ); ?></button>
                </div>
                
                <input type="hidden" id="_vto_optimized_image_url" name="_vto_optimized_image_url" value="<?php echo esc_attr(get_post_meta($post->ID, '_vto_optimized_image_url', true)); ?>" />
                <button type="button" id="vto-upload-optimized-button" class="button button-secondary">
                    <?php echo get_post_meta($post->ID, '_vto_optimized_image_url', true) ? __( 'Substituir imagem', 'wefashion' ) : __( 'Selecionar imagem', 'wefashion' ); ?>
                </button>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            // Lógica de sugestão automática
            $('#_vto_category').on('change', function() {
                const cat = $(this).val();
                if (['dress', 'jumpsuit', 'set'].includes(cat)) {
                    $('#_vto_scope').val('full_body');
                } else if (['pants', 'shorts', 'skirt'].includes(cat)) {
                    $('#_vto_scope').val('lower_body');
                } else if (['top', 'tshirt', 'jacket'].includes(cat)) {
                    $('#_vto_scope').val('upper_body');
                }
            });

            // Lógica do seletor de mídia
            var frame;
            $('#vto-upload-optimized-button').on('click', function(e) {
                e.preventDefault();
                if (frame) { frame.open(); return; }
                frame = wp.media({
                    title: 'Selecione a imagem otimizada',
                    button: { text: 'Usar no provador' },
                    multiple: false
                });
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    $('#_vto_optimized_image_url').val(attachment.url);
                    $('#vto-optimized-image-preview img').attr('src', attachment.url);
                    $('#vto-optimized-image-preview').show();
                    $('#vto-upload-optimized-button').text('Substituir imagem');
                });
                frame.open();
            });

            $('#vto-remove-optimized-image').on('click', function() {
                $('#_vto_optimized_image_url').val('');
                $('#vto-optimized-image-preview').hide();
                $('#vto-upload-optimized-button').text('Selecionar imagem');
            });
        });
        </script>
    </div>
    <?php
}
add_action( 'woocommerce_product_data_panels', 'vto_render_product_admin_tab_content' );

function vto_save_product_settings( $product_id ) {
    $fields = array( '_vto_enabled', '_vto_category', '_vto_scope', '_vto_length', '_vto_fit', '_vto_notes', '_vto_optimized_image_url' );
    foreach ( $fields as $field ) {
        $value = isset( $_POST[$field] ) ? sanitize_text_field( $_POST[$field] ) : '';
        update_post_meta( $product_id, $field, $value );
    }
}
add_action( 'woocommerce_process_product_meta', 'vto_save_product_settings' );

/**
 * Modal HTML
 */
function vto_render_modal_html() {
    static $rendered = false;
    if ($rendered) return;
    $rendered = true;

    global $product;
    $product_name  = $product ? esc_html( $product->get_name() ) : 'Peça selecionada';
    $product_price = $product ? wp_strip_all_tags( wc_price( $product->get_price() ) ) : '';

    $hero_img  = VTO_URL . 'public/vto-hero.jpg';

    ?>
    <div id="vto-modal" class="vto-modal-overlay" role="dialog" aria-modal="true" aria-label="Provador Virtual">
        <div class="vto-modal-content vto-card">

            <div class="vto-modal-body">

                <!-- TELA 1: WELCOME -->
                <div class="vto-screen active-screen" id="vto-screen-1">
                    <div class="vto-card-header">
                        <div class="vto-header-text">
                            <h2 class="vto-card-title">Provador Virtual</h2>
                            <p class="vto-card-sub">Experimente o look em você usando nossa IA.</p>
                        </div>
                        <button type="button" class="vto-modal-close vto-circular-btn" id="vto-global-close" aria-label="Fechar">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                    </div>

                    <div class="vto-welcome-hero">
                        <img src="<?php echo esc_url( $hero_img ); ?>" alt="Welcome" class="vto-card-img" />
                    </div>

                    <div class="vto-card-footer">
                        <button type="button" class="vto-btn vto-btn-primary vto-next-btn" data-next="2">
                            Começar agora
                        </button>
                    </div>
                </div>

                <!-- TELA 2: UPLOAD (Fidelidade UI) -->
                <div class="vto-screen" id="vto-screen-2">
                    <div class="vto-card-header">
                        <div class="vto-header-text">
                            <h2 class="vto-card-title">Provador Virtual</h2>
                            <p class="vto-card-sub">Experimente o look em você sem sair de casa.</p>
                        </div>
                        <button type="button" class="vto-modal-close vto-circular-btn" aria-label="Fechar">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                    </div>

                    <div class="vto-upload-container">
                        <input type="file" id="vto-file-input" accept="image/*" hidden />
                        
                        <div class="vto-preview-zone" id="vto-upload-zone" onclick="document.getElementById('vto-file-input').click()">
                            <div class="vto-zone-content">
                                <svg class="vto-phone-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                    <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                                    <path d="M12 18h.01"></path>
                                    <circle cx="12" cy="11" r="3"></circle>
                                    <path d="M7 21a5 5 0 0 1 10 0"></path>
                                </svg>
                                <span class="vto-zone-text">Carregar sua Foto</span>
                            </div>
                            <img id="vto-image-preview" src="" alt="Sua foto" style="display:none;" />
                        </div>

                        <div class="vto-tip-card">
                            <div class="vto-tip-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"></path></svg>
                            </div>
                            <p class="vto-tip-text">
                                <strong>Capriche na foto!</strong> Escolha uma com boa iluminação e apenas sua, selfie ou corpo inteiro.
                            </p>
                        </div>
                    </div>

                    <div class="vto-action-bar">
                        <button type="button" class="vto-circular-btn vto-camera-btn" onclick="document.getElementById('vto-file-input').click()">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
                        </button>
                        <button type="button" class="vto-btn vto-btn-dark vto-upload-photo-btn" id="vto-upload-next">
                            AVANÇAR
                        </button>
                    </div>
                </div>

                <!-- TELA 3: AJUSTES -->
                <div class="vto-screen" id="vto-screen-3">
                    <div class="vto-card-header">
                        <button type="button" class="vto-back-btn vto-circular-btn vto-next-btn" data-next="2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
                        </button>
                        <div class="vto-header-text" style="text-align:center;">
                            <h2 class="vto-card-title">Medidas</h2>
                            <p class="vto-card-sub">Ajuste para um caimento perfeito.</p>
                        </div>
                        <div style="width:40px;"></div>
                    </div>

                    <div class="vto-card-form">
                        <div class="vto-field-group">
                            <label class="vto-field-label">Altura (cm)</label>
                            <input type="number" id="vto-height" class="vto-input" placeholder="Ex: 175" />
                        </div>
                        <div class="vto-field-group">
                            <label class="vto-field-label">Tamanho Habitual</label>
                            <div class="vto-size-chips" id="vto-size-chips">
                                <button type="button" class="vto-size-chip" data-size="PP">PP</button>
                                <button type="button" class="vto-size-chip" data-size="P">P</button>
                                <button type="button" class="vto-size-chip" data-size="M">M</button>
                                <button type="button" class="vto-size-chip" data-size="G">G</button>
                                <button type="button" class="vto-size-chip" data-size="GG">GG</button>
                            </div>
                            <input type="hidden" id="vto-size" value="" />
                        </div>
                    </div>

                    <div class="vto-card-footer">
                        <button type="button" class="vto-btn vto-btn-primary" id="vto-start-process">
                            Gerar look final
                        </button>
                    </div>
                </div>

                <!-- TELA 4: LOADING -->
                <div class="vto-screen" id="vto-screen-4">
                    <div class="vto-card-loading">
                        <div class="vto-spinner"></div>
                        
                        <!-- Sucesso: Tick Icon -->
                        <svg class="vto-success-icon" viewBox="0 0 52 52">
                            <circle class="vto-check-circle" cx="26" cy="26" r="25" />
                            <path class="vto-check-path" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
                        </svg>

                        <h2 class="vto-card-title" id="vto-loading-title">Gerando Magia...</h2>
                        <p class="vto-card-sub" id="vto-loading-msg">Isto leva cerca de 30 segundos.</p>
                    </div>
                </div>

                    <div class="vto-res-card-white">
                        <button type="button" class="vto-close-main-btn" aria-label="Fechar">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>

                        <div class="vto-res-img-wrap">
                            <img id="vto-result-image" src="" alt="Resultado" />
                            
                            <!-- Apenas o de resetar fica na foto -->
                            <button type="button" class="vto-res-btn-float vto-reset-btn" style="left: 12px;" aria-label="Nova Foto">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
                            </button>
                        </div>

                        <div class="vto-res-content">
                            <h3 id="vto-res-name" class="vto-res-name">...</h3>
                            <div id="vto-res-price" class="vto-res-price">...</div>
                            
                            <!-- Variações (Renderizadas via JS) -->
                            <div id="vto-res-variations" class="vto-res-vars"></div>

                            <!-- Ações Secundárias (Row) -->
                            <div class="vto-res-actions-row">
                                <button type="button" class="vto-btn-outline-small" id="vto-btn-save">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
                                    Salvar Look
                                </button>
                                <button type="button" class="vto-btn-outline-small" id="vto-btn-whatsapp">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12.031 6.172c-2.32 0-4.591.905-6.396 2.548-3.003 2.731-3.413 7.022-1.229 10.29l-1.039 3.81 3.904-1.023c1.321.72 2.812 1.1 4.337 1.102l.003-.001c4.591 0 8.324-3.732 8.324-8.324 0-2.227-.863-4.321-2.43-5.888-1.567-1.567-3.66-2.43-5.887-2.43zm5.035 11.696c-.221.62-.977 1.056-1.567 1.181-.462.098-1.057.17-2.957-.611-2.427-.998-3.992-3.465-4.113-3.626-.12-.16-.977-1.298-.977-2.476s.614-1.756.834-1.996c.221-.24.482-.3.642-.3s.322.001.462.008c.144.008.341-.054.53-.513.193-.467.662-1.611.721-1.731s.098-.261.018-.422c-.08-.16-.2-.361-.3-.482-.101-.121-.221-.261-.321-.362-.112-.112-.234-.234-.1-.422s.595-1.121 1.121-1.121c.526 0 1.056.241 1.376.602s.536.843.616 1.084c.08.241.041.442-.039.602s-.361.361-.482.482c-.121.121-.241.241-.039.442.221.241.482.482.721.721.239.239.52.482.802.682.281.2.562.361.802.482.24.121.401.121.562-.039s.682-1.004.883-1.325.401-.281.682-.16 1.766.83 2.073.985.513.232.589.362c.075.131.075.76-.146 1.38z"/></svg>
                                    Compartilhar
                                </button>
                            </div>

                            <!-- Botão Principal (Preto) -->
                            <button type="button" class="vto-btn vto-btn-buy-black" id="vto-final-buy">
                                ADICIONAR AO CARRINHO
                            </button>
                        </div>
                    </div>
                </div>
                </div>

            </div>
        </div>
    </div>

            </div>
        </div>
    </div>

    <!-- MODAL DE CAPTURA DE LEAD (RECEBA SEU LOOK) -->
    <div id="vto-lead-modal" class="vto-lead-overlay">
        <div class="vto-lead-box">
            <button type="button" class="vto-lead-close">&times;</button>
            <div class="vto-lead-header">
                <span class="vto-lead-badge">Magia concluída!</span>
                <h3>Receba seu look ✨</h3>
                <p>Envie para seu WhatsApp ou email para salvar o resultado e compartilhar com amigos.</p>
            </div>
            
            <form id="vto-lead-form" class="vto-lead-body">
                <div class="vto-lead-input-group">
                    <label>Seu Nome</label>
                    <input type="text" id="vto-lead-name" placeholder="Como deseja ser chamado?" required />
                </div>

                <div class="vto-lead-input-group">
                    <label>Seu WhatsApp</label>
                    <input type="tel" id="vto-lead-whatsapp" placeholder="(00) 00000-0000" />
                </div>
                
                <div class="vto-lead-divider"><span>OU</span></div>
                
                <div class="vto-lead-input-group">
                    <label>Seu melhor e-mail</label>
                    <input type="email" id="vto-lead-email" placeholder="seu@email.com" />
                </div>
                
                <button type="submit" class="vto-btn vto-btn-primary vto-lead-submit">
                    Receber meu look
                </button>
                
                <p class="vto-lead-footer">Você poderá baixar e compartilhar logo em seguida.</p>
            </form>
        </div>
    </div>
    <?php
}
