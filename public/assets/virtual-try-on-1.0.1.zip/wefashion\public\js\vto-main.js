/**
 * Virtual Try-On Main JS - Real Flow
 */

(function($) {
    'use strict';

    const VTO = {
        state: {
            currentScreen: 1,
            userFile: null,
            jobId: null,
            pollingInterval: null,
            maxRetries: 30,
            retries: 0,
            resultImageUrl: null,
            initialized: false,
            // CRM Counters
            looksCount: 0,
            sharesCount: 0,
            clicksCount: 0
        },

        loadingPhrases: [
            { title: "Quase pronto...", subtitle: "Analisando sua foto..." },
            { title: "Entendendo seu estilo...", subtitle: "Ajustando proporções do corpo..." },
            { title: "Simulando o caimento real do tecido...", subtitle: "Aplicando iluminação profissional..." },
            { title: "Criando uma versão exclusiva para você...", subtitle: "Isso vai ficar incrível..." },
            { title: "Finalizando seu look...", subtitle: "Últimos ajustes..." }
        ],

        init: function() {
            if (this.state.initialized) return;
            console.log('VTO: Initialized', vto_data);
            this.bindEvents();
            this.state.initialized = true;
        },

        bindEvents: function() {
            // Open Modal
            $(document).off('click', '#vto-open-modal').on('click', '#vto-open-modal', (e) => {
                e.preventDefault();
                $('#vto-modal').addClass('active').css('display', 'flex');
                this.goToScreen(2);
                $(`#vto-screen-2 .vto-top-bar-back`).hide();
                this.trackEvent('tryon_open');
            });

            // Close Modal
            $(document).off('click', '.vto-modal-close, .vto-btn-close-float, .vto-close-main-btn').on('click', '.vto-modal-close, .vto-btn-close-float, .vto-close-main-btn', () => {
                $('#vto-modal').removeClass('active').css('display', 'none');
                this.reset();
            });

            // Iniciar processamento direto (Pula medidas)
            $(document).on('click', '#vto-upload-next', (e) => {
                e.preventDefault();
                this.startJob();
            });

            // Botões genéricos de navegação
            $(document).on('click', '.vto-next-btn', function(e) {
                e.preventDefault();
                const next = $(this).data('next');
                if (next) VTO.goToScreen(next);
            });

            // File Selection
            $(document).on('change', '#vto-file-input', (e) => {
                const file = e.target.files[0];
                if (file) {
                    this.state.userFile = file;
                    this.showPreview(file);
                    $('#vto-upload-next').show();
                }
            });

            // Save result image
            $(document).on('click', '#vto-btn-save', () => {
                this.state.sharesCount++; // Consideramos salvar como um sinal de interesse
                this.downloadImage();
            });

            // WhatsApp Share
            $(document).on('click', '#vto-btn-whatsapp', () => {
                this.state.sharesCount++;
                this.shareOnWhatsApp();
            });

            // Start Process
            $(document).on('click', '#vto-start-process', () => {
                this.startJob();
            });

            // Reset/Try Again
            $(document).on('click', '.vto-reset-btn', () => {
                this.reset();
                this.goToScreen(2);
            });

            // Final Buy
            $(document).off('click', '#vto-final-buy').on('click', '#vto-final-buy', (e) => {
                const $btn = $(e.currentTarget);
                if ($btn.data('loading')) return;
                $btn.data('loading', true).prop('disabled', true).text('Processando...');
                this.addToCart();
            });

            // --- SHARING & LEAD LOGIC ---

            // Copy Link
            $(document).on('click', '#vto-btn-copy', () => {
                this.trackEvent('share_copy_link');
                this.copyLink();
            });

            // Lead Modal Close
            $(document).on('click', '.vto-lead-close', () => {
                $('#vto-lead-modal').fadeOut(200);
            });

            // Lead Form Submit
            $(document).on('submit', '#vto-lead-form', (e) => {
                e.preventDefault();
                this.submitLead();
            });

            // Size chips — tela 3
            $(document).on('click', '#vto-size-chips .vto-size-chip', function() {
                $('#vto-size-chips .vto-size-chip').removeClass('selected');
                $(this).addClass('selected');
                $('#vto-size').val($(this).data('size'));
            });

            // Variações no Resultado (Tela 5)
            $(document).on('click', '.vto-var-chip', (e) => {
                const $target = $(e.target);
                const attr = $target.data('attribute');
                const val = $target.data('value');

                // Toggle seleção visual na mesma categoria
                $(`.vto-var-chip[data-attribute="${attr}"]`).removeClass('selected');
                $target.addClass('selected');

                // Salva no estado
                this.state.currentSelections[attr] = val;
                this.log(`Variation selected: ${attr}=${val}`, 'info');
            });

            // Toggle Visualização Completa (Contain vs Cover)
            $(document).on('click', '#vto-result-image', (e) => {
                $(e.target).toggleClass('vto-img-contain');
                this.log('Image view toggled', 'info');
            });

            // Fullscreen Close
            $(document).on('click', '.vto-fullscreen-overlay', (e) => {
                if ($(e.target).hasClass('vto-fullscreen-overlay') || $(e.target).closest('.vto-fullscreen-close').length) {
                    this.closeFullscreen();
                }
            });
        },

        goToScreen: function(screenNum) {
            $('.vto-screen').removeClass('active-screen');
            $(`#vto-screen-${screenNum}`).addClass('active-screen');
            
            // Ativa modo imersivo na tela 5
            if (screenNum === 5) {
                // $('.vto-modal-overlay').addClass('vto-mode-immersive'); // Removido para o novo Card Branco
            } else {
                $('.vto-modal-overlay').removeClass('vto-mode-immersive');
            }
            
            this.state.currentScreen = screenNum;
            $('.vto-modal-body').scrollTop(0);
        },

        showPreview: function(file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                $('#vto-image-preview').attr('src', e.target.result).show();
                $('.vto-zone-content').hide();
            };
            reader.readAsDataURL(file);
        },

        startJob: function() {
            if (!this.state.userFile) {
                alert('Por favor, selecione uma foto primeiro.');
                return;
            }

            this.goToScreen(4);
            $('#vto-screen-4').removeClass('vto-state-success'); // Reset state
            const initialPhrase = this.loadingPhrases[0];
            this.updateLoading(initialPhrase.subtitle, initialPhrase.title || "Criando Magia...");
            this.startPhraseRotation();

            const formData = new FormData();
            formData.append('user_image', this.state.userFile);
            formData.append('tenantId', vto_data.tenant_id);
            formData.append('productId', vto_data.product.id);
            formData.append('productType', vto_data.product.type || 'top');
            formData.append('productImageUrl', vto_data.product.image);
            formData.append('optimizedImageUrl', vto_data.product.optimized_image || '');
            formData.append('hasOptimizedImage', vto_data.product.optimized_image ? 'true' : 'false');
            
            const measurements = {
                height: $('#vto-height').val(),
                weight: $('#vto-weight').val(),
                usual_size: $('#vto-size').val()
            };
            formData.append('measurements', JSON.stringify(measurements));
            
            if (vto_data.product.meta) {
                formData.append('garmentMeta', JSON.stringify(vto_data.product.meta));
                
                // Add high-priority foot rendering hints if relevant
                if (vto_data.product.meta.foot_rules) {
                    formData.append('generationHints', vto_data.product.meta.foot_rules);
                }
            }

            fetch(`${vto_data.api_url}/v1/tryon/jobs`, {
                method: 'POST',
                headers: {
                    'X-Public-Key': vto_data.public_key,
                    'X-Tenant-Id': vto_data.tenant_id
                },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const returnedJobId = data.jobId || data.job_id;
                if (data.success && returnedJobId) {
                    this.state.jobId = returnedJobId;
                    this.startPolling();
                } else {
                    throw new Error(data.message || 'Erro ao criar job de provador.');
                }
            })
            .catch(err => this.handleError(err));
        },

        startPolling: function() {
            this.state.retries = 0;

            this.state.pollingInterval = setInterval(() => {
                this.state.retries++;
                
                if (this.state.retries >= this.state.maxRetries) {
                    this.stopPolling();
                    this.handleError(new Error('Tempo limite excedido. Tente novamente em instantes.'));
                    return;
                }

                fetch(`${vto_data.api_url}/v1/tryon/jobs/${this.state.jobId}`, {
                    headers: {
                        'X-Public-Key': vto_data.public_key,
                        'X-Tenant-Id': vto_data.tenant_id
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'done' || data.status === 'completed') {
                        this.goToScreen(5);
                        this.state.looksCount++;
                        this.trackEvent('vto_finish');
                        this.stopPolling();
                        this.fetchResult();
                    } else if (data.status === 'error' || data.status === 'failed') {
                        this.stopPolling();
                        this.handleError(new Error('Houve um erro no processamento da IA.'));
                    }
                })
                .catch(err => console.error('Polling error:', err));
            }, 3000);
        },

        fetchResult: function() {
            // Não mudamos o texto ainda, esperamos o retorno

            fetch(`${vto_data.api_url}/v1/tryon/jobs/${this.state.jobId}/result`, {
                headers: {
                    'X-Public-Key': vto_data.public_key,
                    'X-Tenant-Id': vto_data.tenant_id
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success && data.result_image_url) {
                    this.state.resultImageUrl = data.result_image_url;
                    
                    // --- SUCCESS ANIMATION ---
                    this.stopPhraseRotation();
                    $('#vto-screen-4').addClass('vto-state-success');
                    this.updateLoading("Isso vai ficar incrível...", "Look Criado!");
                    
                    // Small delay to appreciate the checkmark
                    setTimeout(() => {
                        this.showResult(data.result_image_url);
                        this.trackEvent('tryon_generated');
                    }, 1800);
                } else {
                    throw new Error('Nenhuma imagem de resultado encontrada.');
                }
            })
            .catch(err => this.handleError(err));
        },

        showResult: function(imageUrl) {
            $('#vto-result-image').attr('src', imageUrl);
            $('#vto-res-name').text(vto_data.product.name);
            $('#vto-res-price').html(vto_data.product.price_html || 'R$ ' + vto_data.product.price);
            
            this.renderVariations();
            this.goToScreen(5);
        },

        renderVariations: function() {
            const $container = $('#vto-res-variations');
            $container.empty();

            if (!vto_data.attributes || Object.keys(vto_data.attributes).length === 0) return;

            Object.entries(vto_data.attributes).forEach(([attr, options]) => {
                const label = attr.replace('pa_', '').charAt(0).toUpperCase() + attr.replace('pa_', '').slice(1);
                
                let html = `<div class="vto-var-group">
                    <div class="vto-var-label">${label}</div>
                    <div class="vto-var-chips">`;
                
                options.forEach(opt => {
                    html += `<button type="button" class="vto-var-chip" data-attribute="${attr}" data-value="${opt}">${opt}</button>`;
                });

                html += `</div></div>`;
                $container.append(html);
            });
        },

        // --- NEW ACTION LOGIC ---

        handleActionWithLead: function(eventType, callback) {
            if (this.state.leadCaptured) {
                this.trackEvent(eventType);
                callback();
                return;
            }

            // Show lead modal
            this.trackEvent('lead_capture_open');
            $('#vto-lead-modal').fadeIn(300).css('display', 'flex');
            
            // Save callback to run after capture
            this._pendingAction = { eventType, callback };
        },

        submitLead: function() {
            const name = $('#vto-lead-name').val().trim();
            const email = $('#vto-lead-email').val().trim();
            const whatsapp = $('#vto-lead-whatsapp').val().trim();

            if (!name) {
                alert('Por favor, informe seu nome.');
                return;
            }
            if (!email && !whatsapp) {
                alert('Por favor, informe seu WhatsApp ou E-mail para continuar.');
                return;
            }

            const $btn = $('.vto-lead-submit');
            $btn.prop('disabled', true).text('Processando...');

            // 1. Salva no CRM Local (WordPress)
            $.ajax({
                url: vto_data.ajax_url,
                method: 'POST',
                data: {
                    action: 'vto_save_lead',
                    nonce: vto_data.nonce,
                    name: name,
                    email: email,
                    whatsapp: whatsapp,
                    product_id: vto_data.product.id,
                    product_name: vto_data.product.name,
                    image_url: this.state.resultImageUrl,
                    // CRM Data
                    looks_count: this.state.looksCount,
                    shares_count: this.state.sharesCount,
                    clicks_count: this.state.clicksCount,
                    source: 'Provador Virtual',
                    job_id: this.state.jobId
                },
                success: (res) => {
                    this.log('Lead saved to local CRM: ' + res.success, 'info');
                }
            });

            // 2. Envia para o Painel WeFashion (API Central)
            const payload = {
                tenant_id: vto_data.tenant_id,
                job_id: this.state.jobId,
                product_id: vto_data.product.id,
                name: name,
                email: email,
                whatsapp: whatsapp,
                result_image_url: this.state.resultImageUrl,
                source: 'tryon'
            };

            fetch(`${vto_data.api_url}/v1/leads/capture`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(data => {
                if (data.success || true) { // Permitir continuar mesmo se a API central falhar, pois salvamos local
                    this.state.leadCaptured = true;
                    this.trackEvent('lead_captured');
                    $('#vto-lead-modal').fadeOut(200);
                    
                    // Run pending action
                    if (this._pendingAction) {
                        this.trackEvent(this._pendingAction.eventType);
                        this._pendingAction.callback();
                        this._pendingAction = null;
                    }
                } else {
                    $btn.prop('disabled', false).text('Tentar novamente');
                    alert('Erro ao processar. Por favor, tente novamente.');
                }
            })
            .catch(err => {
                this.log('API Error: ' + err.message, 'error');
                // Mesmo com erro na API, se salvou local, podemos considerar sucesso para o usuário
                this.state.leadCaptured = true;
                }
            });
        },

        downloadImage: function() {
            if (!this.state.resultImageUrl) return;
            
            this.log('Redirecting to PHP Proxy Download', 'info');
            
            // Força o download via proxy PHP para contornar CORS e evitar novas abas
            const downloadUrl = `${vto_data.ajax_url}?action=vto_proxy_download&image_url=${encodeURIComponent(this.state.resultImageUrl)}`;
            window.location.href = downloadUrl;
        },

        shareWhatsApp: function() {
            const text = encodeURIComponent(`Olha como ficou esse look em mim 😍👇\n\n${window.location.href}`);
            const url = `https://wa.me/?text=${text}`;
            window.open(url, '_blank');
        },

        copyLink: function() {
            const url = window.location.href;
            navigator.clipboard.writeText(url).then(() => {
                const $btn = $('#vto-btn-copy span');
                const originalText = $btn.text();
                $btn.text('Link copiado!');
                setTimeout(() => $btn.text(originalText), 2000);
            });
        },

        trackEvent: function(eventType) {
            const eventData = {
                tenant_id: vto_data.tenant_id,
                job_id: this.state.jobId,
                event: eventType,
                timestamp: new Date().toISOString()
            };

            // Non-blocking ping for analytics (to tryon/events or standard log)
            fetch(`${vto_data.api_url}/v1/tryon/events`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-Public-Key': vto_data.public_key },
                body: JSON.stringify({ metric: eventType, value: 1 })
            }).catch(e => {});

            // Also log locally in WP
            this.log(`Event: ${eventType}`, 'info');
        },

        handleError: function(err) {
            console.error('VTO Error:', err);
            this.log(`Erro: ${err.message}`, 'error');
            alert('Ops! ' + err.message);
            this.goToScreen(3);
        },

        stopPolling: function() {
            if (this.state.pollingInterval) {
                clearInterval(this.state.pollingInterval);
                this.state.pollingInterval = null;
            }
            this.stopPhraseRotation();
        },

        startPhraseRotation: function() {
            this.state.phraseInterval = setInterval(() => {
                this.state.phraseIndex++;
                if (this.state.phraseIndex >= this.loadingPhrases.length) {
                    this.state.phraseIndex = 0;
                }
                const phrase = this.loadingPhrases[this.state.phraseIndex];
                this.updateLoading(phrase.subtitle, phrase.title);
            }, 2500);
        },

        stopPhraseRotation: function() {
            if (this.state.phraseInterval) {
                clearInterval(this.state.phraseInterval);
                this.state.phraseInterval = null;
            }
        },

        updateLoading: function(msg, title) {
            if (title) $('#vto-loading-title').text(title);
            $('#vto-loading-msg').text(msg);
        },

        addToCart: function() {
            this.trackEvent('conversion');
            const productId = vto_data.product.id;
            
            // Tenta encontrar o variation_id se for variável
            let variationId = 0;
            if (vto_data.variations && vto_data.variations.length > 0) {
                const match = vto_data.variations.find(v => {
                    // Compara cada atributo selecionado com os atributos da variação
                    return Object.entries(this.state.currentSelections).every(([attr, val]) => {
                        return v.attributes[`attribute_${attr}`] === val || v.attributes[attr] === val;
                    });
                });
                
                if (match) {
                    variationId = match.variation_id;
                } else {
                    alert('Por favor, selecione as opções de cor e tamanho acima para adicionar ao carrinho.');
                    return;
                }
            }

            const targetId = (variationId && variationId !== 0) ? variationId : productId;
            
            // Build checkout URL with variation data
            let url = `?add-to-cart=${targetId}`;
            Object.entries(this.state.currentSelections).forEach(([attr, val]) => {
                url += `&attribute_${attr}=${encodeURIComponent(val)}`;
            });

            window.location.href = url;
            this.state.clicksCount++;
        },

        saveLook: function() {
            if (!this.state.resultImageUrl) return;
            const link = document.createElement('a');
            link.href = this.state.resultImageUrl;
            link.target = '_blank';
            link.download = `wefashion-look-${Date.now()}.jpg`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            this.log('Result image saved (download)', 'info');
        },

        shareOnWhatsApp: function() {
            if (!this.state.resultImageUrl) return;
            const text = `Olha o look que montei na ${vto_data.tenant_id || 'WeFashion'}! ✨ ${this.state.resultImageUrl}`;
            const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
            window.open(url, '_blank');
            this.log('Shared results on WhatsApp', 'info');
        },

        log: function(msg, type) {
            $.post(vto_data.ajax_url, {
                action: 'vto_log_event',
                nonce: vto_data.nonce,
                log_message: msg,
                log_type: type
            });
        },

        reset: function() {
            this.stopPolling();
            this.state.userFile = null;
            this.state.jobId = null;
            this.state.retries = 0;
            this.state.resultImageUrl = null;
            $('#vto-file-input').val('');
            $('#vto-image-preview').attr('src', '').hide();
            $('.vto-zone-content').show();
            $('#vto-height, #vto-weight').val('');
            $('#vto-size').val('');
        },

        // --- FULLSCREEN MODULE ---
        openFullscreen: function() {
            if (!this.state.resultImageUrl) return;

            if ($('#vto-fullscreen').length === 0) {
                this.createFullscreenMarkup();
            }

            const $overlay = $('#vto-fullscreen');
            $overlay.find('.vto-fullscreen-img').attr('src', this.state.resultImageUrl);
            $overlay.addClass('active');
            $('body').css('overflow', 'hidden');
            this.trackEvent('view_fullscreen');

            this.initSwipeToClose($overlay);
        },

        closeFullscreen: function() {
            const $overlay = $('#vto-fullscreen');
            $overlay.removeClass('active');
            $('body').css('overflow', '');
            
            // Remove swipe listeners when closing
            $overlay.off('touchstart touchmove touchend');
        },

        createFullscreenMarkup: function() {
            const markup = `
                <div id="vto-fullscreen" class="vto-fullscreen-overlay">
                    <button class="vto-fullscreen-close">&times;</button>
                    <img class="vto-fullscreen-img" src="" alt="Fullscreen Look" />
                    <div class="vto-fullscreen-swipe-indicator">Deslize para baixo para fechar</div>
                </div>
            `;
            $('body').append(markup);
        },

        initSwipeToClose: function($el) {
            let startY = 0;
            let currentY = 0;
            const threshold = 100;
            const $img = $el.find('.vto-fullscreen-img');

            $el.on('touchstart', function(e) {
                startY = e.touches[0].clientY;
                $img.css('transition', 'none');
            });

            $el.on('touchmove', function(e) {
                currentY = e.touches[0].clientY;
                const delta = currentY - startY;
                
                if (delta > 0) {
                    $img.css('transform', `translateY(${delta}px) scale(${1 - (delta/1000)})`);
                    $el.css('background', `rgba(11, 12, 13, ${0.98 - (delta/500)})`);
                }
            });

            $el.on('touchend', (e) => {
                const delta = currentY - startY;
                $img.css('transition', '');
                $el.css('background', '');

                if (delta > threshold) {
                    this.closeFullscreen();
                } else {
                    $img.css('transform', '');
                }
                
                // Reset values
                startY = 0;
                currentY = 0;
            });
        }
    };

    $(document).ready(() => {
        VTO.init();
    });

})(jQuery);
