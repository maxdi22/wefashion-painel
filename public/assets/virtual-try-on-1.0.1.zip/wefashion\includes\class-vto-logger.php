<?php
/**
 * Logger class for Virtual Try-On failures and status
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VTO_Logger {
    private static $option_name = 'vto_integration_logs';

    /**
     * Log a failure or a success message
     */
    public static function log( $message, $type = 'info' ) {
        $logs = get_option( self::$option_name, array() );
        
        // Mantém apenas os últimos 20 logs
        if ( count( $logs ) >= 20 ) {
            array_shift( $logs );
        }

        $logs[] = array(
            'timestamp' => current_time( 'mysql' ),
            'message'   => $message,
            'type'      => $type,
        );

        update_option( self::$option_name, $logs );
    }

    /**
     * Get all logs
     */
    public static function get_logs() {
        return array_reverse( get_option( self::$option_name, array() ) );
    }

    /**
     * Clear all logs
     */
    public static function clear_logs() {
        delete_option( self::$option_name );
    }
}
